// Supabase Edge Function.
// Set an AI provider key as a secret. Example:
// supabase secrets set OPENAI_API_KEY=...
// This function keeps the secret off the client.
//
// The response is deliberately structured so the UI can later render
// real interactive mind maps and quizzes.

import { serve } from "https://deno.land/std@0.224.0/http/server.ts";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });

  try {
    const { action, payload } = await req.json();
    const key = Deno.env.get("OPENAI_API_KEY");
    if (!key) return json({error:"OPENAI_API_KEY n'est pas configurée dans les secrets Supabase."}, 500);

    const system = `Tu es un professeur d'espagnol exceptionnel.
Réponds en français pour les explications, mais garde les mots, exemples et phrases d'apprentissage en espagnol.
Sois très détaillé, pédagogique et exact. Pour les verbes, donne infinitif, traduction, usage, conjugaison utile et exemples.
Pour une leçon, structure: objectifs, vocabulaire, grammaire, exemples, astuces mnémotechniques, erreurs fréquentes, exercices et corrigé.
Pour une carte mentale, structure les branches et sous-branches clairement.
Pour un quiz, donne questions, choix si pertinent, réponse correcte et explication.`;

    const prompt = `Action: ${action}
Demande: ${JSON.stringify(payload)}
Retourne un résultat exploitable par une application éducative.`;

    const r = await fetch("https://api.openai.com/v1/chat/completions", {
      method:"POST",
      headers:{"Content-Type":"application/json","Authorization":`Bearer ${key}`},
      body:JSON.stringify({
        model:"gpt-5",
        messages:[{role:"system",content:system},{role:"user",content:prompt}],
        temperature:0.4
      })
    });
    const data = await r.json();
    if (!r.ok) return json({error:data?.error?.message||"Erreur du fournisseur IA"}, r.status);
    return json({type:action, content:data.choices?.[0]?.message?.content||""});
  } catch(e) {
    return json({error:String(e)},500);
  }
});

function json(data,status=200){
 return new Response(JSON.stringify(data),{status,headers:{...cors,"Content-Type":"application/json"}});
}
