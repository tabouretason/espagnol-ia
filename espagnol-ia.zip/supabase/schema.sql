create table if not exists public.learning_items (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 type text not null,
 title text not null,
 content jsonb not null default '{}'::jsonb,
 created_at timestamptz not null default now()
);

alter table public.learning_items enable row level security;

create policy "users can read own items" on public.learning_items
for select using (auth.uid() = user_id);

create policy "users can insert own items" on public.learning_items
for insert with check (auth.uid() = user_id);

create policy "users can update own items" on public.learning_items
for update using (auth.uid() = user_id);

create policy "users can delete own items" on public.learning_items
for delete using (auth.uid() = user_id);

-- Storage bucket for course photos:
insert into storage.buckets (id,name,public) values ('course-photos','course-photos',false)
on conflict (id) do nothing;

create policy "users manage own photos" on storage.objects
for all using (bucket_id='course-photos' and auth.uid()::text = (storage.foldername(name))[1])
with check (bucket_id='course-photos' and auth.uid()::text = (storage.foldername(name))[1]);
