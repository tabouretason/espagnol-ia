import React,{useEffect,useState} from 'react';
import {createRoot} from 'react-dom/client';
import {createClient} from '@supabase/supabase-js';
import {BookOpen,Brain,FileText,Gamepad2,Home,ImagePlus,LogOut,Menu,Plus,Send,Sparkles,X} from 'lucide-react';
import './style.css';

const supabase=createClient(import.meta.env.VITE_SUPABASE_URL||'',import.meta.env.VITE_SUPABASE_ANON_KEY||'');

function Auth({onDone}){
 const [mode,setMode]=useState('login'),[email,setEmail]=useState(''),[password,setPassword]=useState(''),[msg,setMsg]=useState('');
 async function go(e){e.preventDefault();setMsg('');
  const r=mode==='login'?await supabase.auth.signInWithPassword({email,password}):await supabase.auth.signUp({email,password});
  if(r.error)setMsg(r.error.message);else {setMsg(mode==='signup'?'Vérifie ton e-mail puis connecte-toi.':'Connexion réussie.'); if(r.data.session)onDone(r.data.session.user);}
 }
 return <div className="auth"><div className="authbox"><div className="logo big">🇪🇸</div><h1>Espagnol IA</h1><p>Ton professeur d'espagnol intelligent.</p><form onSubmit={go}><input type="email" placeholder="Adresse e-mail" value={email} onChange={e=>setEmail(e.target.value)} required/><input type="password" placeholder="Mot de passe" value={password} onChange={e=>setPassword(e.target.value)} required minLength="6"/><button className="primary">{mode==='login'?'Se connecter':'Créer mon compte'}</button></form>{msg&&<div className="notice">{msg}</div>}<button className="link" onClick={()=>setMode(mode==='login'?'signup':'login')}>{mode==='login'?'Créer un compte':'J’ai déjà un compte'}</button></div></div>
}

async function ai(action,payload){
 const {data,error}=await supabase.functions.invoke('ai',{body:{action,payload}});
 if(error)throw error;if(data?.error)throw new Error(data.error);return data;
}

function App({user}){
 const [tab,setTab]=useState('home'),[items,setItems]=useState([]),[loading,setLoading]=useState(true),[modal,setModal]=useState(null),[result,setResult]=useState(null),[busy,setBusy]=useState(false);
 useEffect(()=>load(),[]);
 async function load(){setLoading(true);const {data,error}=await supabase.from('learning_items').select('*').order('created_at',{ascending:false});if(!error)setItems(data||[]);setLoading(false)}
 async function save(type,title,content){const {data,error}=await supabase.from('learning_items').insert({user_id:user.id,type,title,content}).select().single();if(!error)setItems(x=>[data,...x]);else alert(error.message)}
 async function generate(action,payload){setBusy(true);setResult(null);try{const r=await ai(action,payload);setResult(r);await save(action,payload.title||'Création IA',r)}catch(e){alert("IA : "+e.message)}finally{setBusy(false)}}
 const cards=items.filter(x=>x.type==='mindmap'),courses=items.filter(x=>x.type==='course'||x.type==='lesson'),quizzes=items.filter(x=>x.type==='quiz');
 return <div className="app"><aside className="side"><div className="brand">🇪🇸 <b>Espagnol IA</b></div>{[['home','Accueil',Home],['courses','Mes cours',BookOpen],['mindmaps','Cartes mentales',Brain],['quiz','Quiz IA',Gamepad2],['assistant','Créer avec IA',Sparkles]].map(([id,t,I])=><button className={tab===id?'nav active':'nav'} onClick={()=>setTab(id)} key={id}><I size={19}/>{t}</button>)}<div className="sidebottom"><span>{user.email}</span><button className="nav" onClick={()=>supabase.auth.signOut()}><LogOut size={18}/>Déconnexion</button></div></aside>
 <main><header><button className="mobileMenu" onClick={()=>document.querySelector('.side').classList.toggle('open')}><Menu/></button><h2>{tab==='home'?'Bonjour 👋':tab==='mindmaps'?'Mes cartes mentales':tab==='courses'?'Mes cours':tab==='quiz'?'Mes quiz':'Créer avec l’IA'}</h2><button className="plus" onClick={()=>setModal('new')}><Plus/> Nouveau</button></header>
 {tab==='home'&&<><section className="hero"><div><div className="pill">🤖 PROFESSEUR IA</div><h1>Apprends l’espagnol<br/>à ta façon.</h1><p>Transforme tes cours en cartes mentales, crée des leçons et entraîne-toi avec des quiz générés par l’IA.</p><button className="primary" onClick={()=>setModal('photo')}><ImagePlus/> Photographier un cours</button></div><div className="heroemoji">🧠</div></section><div className="stats"><Stat n={courses.length} t="Cours"/><Stat n={cards.length} t="Cartes mentales"/><Stat n={quizzes.length} t="Quiz"/></div><h3>Créations récentes</h3><List items={items.slice(0,6)}/></>}
 {tab==='mindmaps'&&<><button className="create" onClick={()=>setModal('mindmap')}>+ Créer une carte mentale</button><List items={cards}/></>}
 {tab==='courses'&&<><button className="create" onClick={()=>setModal('lesson')}>✨ Créer une leçon avec l’IA</button><List items={courses}/></>}
 {tab==='quiz'&&<><button className="create" onClick={()=>setModal('quiz')}>📝 Créer un quiz avec l’IA</button><List items={quizzes}/></>}
 {tab==='assistant'&&<Assistant onGenerate={generate} busy={busy}/>}
 {loading&&<div className="notice">Chargement de tes sauvegardes…</div>}
 </main>
 {modal&&<Modal type={modal} close={()=>setModal(null)} generate={generate} busy={busy}/>}
 {result&&<div className="result"><button className="close" onClick={()=>setResult(null)}><X/></button><pre>{typeof result==='string'?result:JSON.stringify(result,null,2)}</pre></div>}
 </div>
}
function Stat({n,t}){return <div className="stat"><b>{n}</b><span>{t}</span></div>}
function List({items}){if(!items.length)return <div className="empty">Rien pour le moment. Clique sur <b>Nouveau</b> pour commencer.</div>;return <div className="grid">{items.map(x=><article className="card" key={x.id}><div className="type">{x.type}</div><h3>{x.title}</h3><p>{typeof x.content==='string'?x.content.slice(0,140):'Créé avec l’IA'}</p></article>)}</div>}
function Assistant({onGenerate,busy}){const [q,setQ]=useState('');return <div className="assistant"><div className="aihead">✨ <b>Créer avec l’IA</b><span>Demande-lui ce que tu veux apprendre.</span></div><textarea value={q} onChange={e=>setQ(e.target.value)} placeholder="Exemple : crée-moi une leçon détaillée sur la description physique en espagnol…"/><button className="primary" disabled={!q||busy} onClick={()=>onGenerate('lesson',{title:q,request:q,language:'es',explanationLanguage:'fr'})}><Send/> {busy?'Création…':'Créer avec l’IA'}</button><div className="suggestions"><button onClick={()=>setQ('Crée-moi une leçon détaillée sur la description physique.')}>Description physique</button><button onClick={()=>setQ('Explique-moi SER et ESTAR avec conjugaison et exemples.')}>SER vs ESTAR</button><button onClick={()=>setQ('Crée-moi une leçon sur les nombres de 1 à 100.')}>Les nombres</button></div></div>}
function Modal({type,close,generate,busy}){const [title,setTitle]=useState(''),[text,setText]=useState('');const isPhoto=type==='photo';let label=type==='lesson'?'Créer une leçon':type==='mindmap'?'Créer une carte mentale':type==='quiz'?'Créer un quiz':'Transformer une photo';return <div className="overlay"><div className="modal"><button className="close" onClick={close}><X/></button><h2>{label}</h2>{isPhoto?<><input type="file" accept="image/*" multiple onChange={e=>setText([...e.target.files].map(f=>f.name).join(', '))}/><p>Dans la version connectée, la photo est envoyée à l’IA pour lire le cours et générer la carte mentale.</p></>:<><input value={title} onChange={e=>setTitle(e.target.value)} placeholder={type==='quiz'?'Sujet du quiz':'Titre ou demande'}/><textarea value={text} onChange={e=>setText(e.target.value)} placeholder={type==='lesson'?'Ex : une leçon très détaillée sur la description physique…':type==='mindmap'?'Ex : une carte mentale sur SER et ESTAR…':'Ex : quiz difficile sur cette leçon…'}/></>}<button className="primary" disabled={busy||(!isPhoto&&!text)} onClick={()=>{if(isPhoto){alert("Ajoute ici le stockage photo + analyse IA après configuration Supabase.");return}generate(type==='lesson'?'lesson':type,{title:title||text,prompt:text||title,language:'es',explanationLanguage:'fr'});close()}}>{busy?'Création…':'✨ Générer avec l’IA'}</button></div></div>}
supabase.auth.getSession().then(({data})=>{createRoot(document.getElementById('root')).render(data.session?<App user={data.session.user}/>:<Auth onDone={()=>location.reload()}/>);});
supabase.auth.onAuthStateChange((_e,s)=>{createRoot(document.getElementById('root')).render(s?<App user={s.user}/>:<Auth onDone={()=>{}}/>);});
