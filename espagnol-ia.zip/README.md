# Espagnol IA

Application web d'apprentissage de l'espagnol avec :
- authentification Supabase
- sauvegarde cloud des cours/cartes/quiz
- import de photos de cours
- génération de cours, cartes mentales et quiz via une fonction serveur
- interface responsive iPad

## Démarrage
1. Installer Node.js.
2. `npm install`
3. Copier `.env.example` vers `.env`
4. Renseigner l'URL et la clé publique Supabase.
5. Créer les tables SQL avec `supabase/schema.sql`.
6. Déployer `supabase/functions/ai/index.ts` comme fonction Supabase.
7. Ajouter la clé du fournisseur IA dans les secrets de la fonction.

L'application ne met jamais la clé secrète IA dans le navigateur.
